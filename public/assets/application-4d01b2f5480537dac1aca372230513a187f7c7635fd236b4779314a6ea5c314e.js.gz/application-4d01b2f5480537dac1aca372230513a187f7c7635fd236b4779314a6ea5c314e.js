(function() {
  console.log("in application cofeee");

}).call(this);
